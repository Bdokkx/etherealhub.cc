"use client"

import { useState } from "react"
import { X, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ScriptModalProps {
  isOpen: boolean
  onClose: () => void
}

export function ScriptModal({ isOpen, onClose }: ScriptModalProps) {
  const [copied, setCopied] = useState(false)

  const scriptCode = `loadstring(game:HttpGet("https://etherealhub.cc/api/script"))()`

  const handleCopy = () => {
    navigator.clipboard.writeText(scriptCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-4 animate-scale-in">
        <div className="bg-[#0a0a0a] border border-[#222222] rounded-2xl overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-[#222222]">
            <h2 className="text-white font-semibold">Get Script</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-4">
            <p className="text-gray-400 text-sm mb-4">
              Copy the script below and execute it in your executor.
            </p>

            {/* Code Block with Lua Syntax Highlighting */}
            <div className="relative bg-[#141414] border border-[#222222] rounded-xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-2 border-b border-[#222222] bg-[#0d0d0d]">
                <span className="text-gray-500 text-xs font-mono">lua</span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 px-2 text-gray-400 hover:text-white hover:bg-white/10"
                  onClick={handleCopy}
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 mr-1 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-1" />
                      Copy
                    </>
                  )}
                </Button>
              </div>
              
              <div className="p-6 overflow-x-auto">
                <pre className="text-base font-mono">
                  <code>
                    <span className="text-[#c586c0]">loadstring</span>
                    <span className="text-white">(</span>
                    <span className="text-[#dcdcaa]">game</span>
                    <span className="text-white">:</span>
                    <span className="text-[#dcdcaa]">HttpGet</span>
                    <span className="text-white">(</span>
                    <span className="text-[#ce9178]">&quot;https://etherealhub.cc/api/script&quot;</span>
                    <span className="text-white">))()</span>
                  </code>
                </pre>
              </div>
            </div>

            
          </div>
        </div>
      </div>
    </div>
  )
}
