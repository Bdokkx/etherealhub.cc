"use client"

import { ArrowLeft, ExternalLink } from "lucide-react"
import Image from "next/image"

interface ProviderModalProps {
  isOpen: boolean
  onClose: () => void
  onBack: () => void
}

export function ProviderModal({ isOpen, onClose, onBack }: ProviderModalProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg mx-4 animate-scale-in">
        <div className="text-center mb-8 animate-fade-in-up">
          <h1 className="text-3xl font-bold mb-2">
            <span className="text-gradient">Get Your</span>{" "}
            <span className="text-white">Ethereal</span>{" "}
            <span className="text-gradient">Key</span>
          </h1>
          <p className="text-gray-500">Choose your preferred method to get your script key</p>
        </div>

        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 hover:text-white mb-4 transition-all duration-300 hover:translate-x-[-4px]"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to options
        </button>

        <div className="bg-[#0a0a0a] border border-[#222222] rounded-xl p-6">
          <h2 className="text-white font-semibold text-center mb-4">Choose Your Provider</h2>

          <div className="space-y-3">
            {/* Lootlabs Provider */}
            <div
              className="relative flex items-center justify-between p-4 bg-[#141414] border border-[#222222] rounded-xl cursor-pointer transition-all duration-300 hover:border-white/20 hover:scale-[1.02]"
              onClick={() => window.open("https://lootlabs.gg", "_blank")}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center">
                  <Image
                    src="/lootlabs.png"
                    alt="Lootlabs"
                    width={40}
                    height={40}
                    className="object-cover"
                  />
                </div>
                <div>
                  <div className="text-white font-medium">Lootlabs</div>
                  <div className="text-gray-500 text-sm">
                    1 checkpoint • 18h duration
                  </div>
                </div>
              </div>
              <ExternalLink className="w-5 h-5 text-gray-500" />
            </div>
          </div>

          <p className="text-gray-600 text-xs text-center mt-4">
            If the key link doesn&apos;t open, try disabling your adblocker.
          </p>
          <button className="flex items-center justify-center gap-1 text-gray-500 hover:text-white text-sm mx-auto mt-2 transition-all duration-300">
            How does this work?
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  )
}
