"use client"

import { useState } from "react"
import { ArrowLeft, Check, Star, ExternalLink, Link } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FloatingParticles } from "@/components/floating-particles"
import { ProviderModal } from "@/components/provider-modal"
import NextLink from "next/link"

export default function KeyPage() {
  const [showProvider, setShowProvider] = useState(false)

  const premiumFeatures = [
    "Instant key delivery",
    "Zero checkpoints required",
    "Priority Discord support",
    "Early access to new features",
  ]

  const freeFeatures = [
    "Single checkpoint only",
    "No payment required",
    "Community support",
    "Renewable anytime",
  ]

  return (
    <main className="min-h-screen bg-black relative overflow-hidden">
      <FloatingParticles />
      
      <div className="relative z-10 flex items-center justify-center min-h-screen px-4">
        <NextLink
          href="/"
          className="absolute top-6 left-6 text-gray-500 hover:text-white transition-all duration-300 hover:scale-110"
        >
          <ArrowLeft className="w-6 h-6" />
        </NextLink>

        <div className="w-full max-w-4xl mx-4">
          <div className="text-center mb-8 animate-fade-in-up">
            <h1 className="text-3xl font-bold mb-2">
              <span className="text-gradient">Get Your</span>{" "}
              <span className="text-white">Ethereal</span>{" "}
              <span className="text-gradient">Key</span>
            </h1>
            <p className="text-gray-500">Choose your preferred method to get your script key</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Premium Card */}
            <div 
              className="relative bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 opacity-0 animate-scale-in transition-all duration-300 hover:border-white/30 hover:shadow-[0_0_40px_rgba(255,255,255,0.1)]"
              style={{ animationDelay: '0.1s', animationFillMode: 'forwards' }}
            >
              <div className="absolute -top-3 right-6 bg-white text-black text-xs px-3 py-1 rounded-full flex items-center gap-1 font-medium">
                <Star className="w-3 h-3" /> BEST VALUE
              </div>

              <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-4">
                <Star className="w-6 h-6 text-white" />
              </div>

              <h2 className="text-xl font-semibold text-white mb-1">Premium</h2>
              <p className="text-gray-500 text-sm mb-4">Monthly access with no restrictions</p>

              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-bold text-gradient">4.99€</span>
                <span className="text-gray-500">/monthly</span>
              </div>

              <ul className="space-y-3 mb-6">
                {premiumFeatures.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-gray-300">
                    <Check className="w-5 h-5 text-white" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                className="w-full bg-white hover:bg-gray-100 text-black py-6 font-medium transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,255,255,0.3)]"
                onClick={() => window.open('https://discord.gg/ktcZ44EP', '_blank')}
              >
                Purchase Now
              </Button>
            </div>

            {/* Free Key Card */}
            <div 
              className="bg-[#0a0a0a] border border-[#222222] rounded-2xl p-6 opacity-0 animate-scale-in transition-all duration-300 hover:border-white/20"
              style={{ animationDelay: '0.2s', animationFillMode: 'forwards' }}
            >
              <div className="w-12 h-12 bg-[#141414] rounded-xl flex items-center justify-center mb-4">
                <Link className="w-6 h-6 text-gray-400" />
              </div>

              <h2 className="text-xl font-semibold text-white mb-1">Free Key</h2>
              <p className="text-gray-500 text-sm mb-4">Get access without payment</p>

              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-bold text-emerald-400">Free</span>
                <span className="text-gray-500">12-16 hours</span>
              </div>

              <ul className="space-y-3 mb-6">
                {freeFeatures.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-gray-300">
                    <Check className="w-5 h-5 text-emerald-400" />
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                variant="outline"
                className="w-full border-[#222222] bg-[#141414] text-white hover:bg-[#1a1a1a] py-6 transition-all duration-300 hover:border-white/20"
                onClick={() => setShowProvider(true)}
              >
                Choose Provider
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>

          {/* Footer Links */}
          <div className="text-center mt-8 opacity-0 animate-fade-in-up" style={{ animationDelay: '0.3s', animationFillMode: 'forwards' }}>
            <p className="text-gray-600 text-sm">
              By using this, you agree to our{" "}
              <NextLink href="/terms" className="text-gray-400 hover:text-white transition-colors">Terms of Service</NextLink> and{" "}
              <NextLink href="/privacy" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</NextLink>.
            </p>
          </div>
        </div>
      </div>

      <ProviderModal
        isOpen={showProvider}
        onClose={() => setShowProvider(false)}
        onBack={() => setShowProvider(false)}
      />
    </main>
  )
}
