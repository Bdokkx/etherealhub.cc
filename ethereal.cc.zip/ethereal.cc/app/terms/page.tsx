"use client"

import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function TermsOfService() {
  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-gray-500 hover:text-white transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <h1 className="text-4xl font-bold mb-2">Terms of Service</h1>
        <p className="text-gray-500 mb-8">Last updated: January 2026</p>

        <div className="space-y-8 text-gray-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-3">1. Acceptance of Terms</h2>
            <p className="leading-relaxed">
              By accessing and using Ethereal ("the Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our Service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">2. License to Use</h2>
            <p className="leading-relaxed mb-4">
              We grant you a limited, non-exclusive, non-transferable license to use the Ethereal script for personal, non-commercial purposes in accordance with these terms.
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-400">
              <li>You may not redistribute or sell the script.</li>
              <li>You may not reverse engineer, decompile, or disassemble the script.</li>
              <li>You may not use the script for malicious purposes.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">3. Disclaimer of Warranties</h2>
            <p className="leading-relaxed">
              The Service is provided "as is" without any warranties, expressed or implied. We do not guarantee that the script will be error-free, secure, or uninterrupted. Use it at your own risk.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">4. Limitation of Liability</h2>
            <p className="leading-relaxed">
              In no event shall Ethereal or its developers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the Service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">5. Third-Party Services</h2>
            <p className="leading-relaxed">
              Our Service may contain links to third-party web sites or services (such as checkpoint providers) that are not owned or controlled by Ethereal. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third party web sites or services.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">6. Changes to Terms</h2>
            <p className="leading-relaxed">
              We reserve the right to modify these terms at any time. We will notify users of any changes by updating the date at the top of this page. Your continued use of the Service after any such changes constitutes your acceptance of the new Terms of Service.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">7. Contact Us</h2>
            <p className="leading-relaxed">
              If you have any questions about these Terms, please contact us via our{" "}
              <a
                href="https://discord.gg/ktcZ44EP"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:underline"
              >
                Discord community
              </a>
              .
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}
