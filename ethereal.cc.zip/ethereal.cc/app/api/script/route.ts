export async function GET() {
  const script = `loadstring(game:HttpGet("https://etherealhub.cc/api/main"))()`

  return new Response(script, {
    status: 200,
    headers: {
      'Content-Type': 'text/plain',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
    },
  })
}
