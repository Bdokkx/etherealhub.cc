"use client"

import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function PrivacyPolicy() {
  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-gray-500 hover:text-white transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <h1 className="text-4xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-gray-500 mb-8">Last updated: January 2026</p>

        <div className="space-y-8 text-gray-300">
          <section>
            <h2 className="text-xl font-semibold text-white mb-3">1. Information We Collect</h2>
            <p className="leading-relaxed mb-4">
              We adhere to a strict no-logs policy. We do not collect personal information that can identify you. However, we may automatically collect certain non-personal information when you visit our website or use our script, such as:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-400">
              <li>Device type and browser information (for compatibility).</li>
              <li>Anonymous usage data to help us improve the Service.</li>
              <li>HWID (Hardware ID) for license key verification purposes only.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">2. How We Use Information</h2>
            <p className="leading-relaxed">
              Any information we collect is used solely for the purpose of getting you access to the script and improving the quality of our Service. We do not sell, trade, or rent your information to others.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">3. Cookies</h2>
            <p className="leading-relaxed">
              We use local storage and essential cookies to store your preferences (such as your license key) locally on your device. These are used strictly for functionality and not for tracking.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">4. Third-Party Services</h2>
            <p className="leading-relaxed">
              We may use third-party providers (like link shorteners for the key system) which may have their own privacy policies. We encourage you to review the privacy policies of any third-party sites you interact with.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">5. Data Security</h2>
            <p className="leading-relaxed">
              We implement reasonable security measures to protect against unauthorized access to or unauthorized alteration, disclosure, or destruction of data. However, no data transmission over the Internet is 100% secure.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">6. Changes to This Policy</h2>
            <p className="leading-relaxed">
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-white mb-3">7. Contact Us</h2>
            <p className="leading-relaxed">
              If you have any questions about this Privacy Policy, please contact us via our{" "}
              <a
                href="https://discord.gg/ktcZ44EP"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:underline"
              >
                Discord community
              </a>
              .
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}
